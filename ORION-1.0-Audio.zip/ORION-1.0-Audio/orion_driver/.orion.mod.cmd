savedcmd_orion.mod := printf '%s\n'   orion.o | awk '!x[$$0]++ { print("./"$$0) }' > orion.mod
