savedcmd_orion.o := gcc -Wp,-MMD,./.orion.o.d -nostdinc -I/usr/src/kernels/7.1.3-200.fc44.x86_64/arch/x86/include -I/usr/src/kernels/7.1.3-200.fc44.x86_64/arch/x86/include/generated -I/usr/src/kernels/7.1.3-200.fc44.x86_64/include -I/usr/src/kernels/7.1.3-200.fc44.x86_64/include -I/usr/src/kernels/7.1.3-200.fc44.x86_64/arch/x86/include/uapi -I/usr/src/kernels/7.1.3-200.fc44.x86_64/arch/x86/include/generated/uapi -I/usr/src/kernels/7.1.3-200.fc44.x86_64/include/uapi -I/usr/src/kernels/7.1.3-200.fc44.x86_64/include/generated/uapi -include /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/compiler-version.h -include /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/kconfig.h -include /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/compiler_types.h -D__KERNEL__ -fshort-wchar -funsigned-char -fno-common -fno-PIE -fno-strict-aliasing -std=gnu11 -fms-extensions -mno-sse -mno-mmx -mno-sse2 -mno-3dnow -mno-avx -mno-sse4a -fcf-protection=branch -fno-jump-tables -m64 -falign-jumps=1 -falign-loops=1 -mno-80387 -mno-fp-ret-in-387 -mpreferred-stack-boundary=3 -mskip-rax-setup -march=x86-64 -mtune=generic -mno-red-zone -mcmodel=kernel -mstack-protector-guard-reg=gs -mstack-protector-guard-symbol=__ref_stack_chk_guard -Wno-sign-compare -fno-asynchronous-unwind-tables -mindirect-branch=thunk-extern -mindirect-branch-register -mindirect-branch-cs-prefix -mfunction-return=thunk-extern -fno-jump-tables -mharden-sls=all -fpatchable-function-entry=16,16 -fno-delete-null-pointer-checks -O2 -fno-allow-store-data-races -fstack-protector-strong -ftrivial-auto-var-init=zero -fzero-init-padding-bits=all -fno-stack-clash-protection -fdiagnostics-show-context=2 -pg -mrecord-mcount -mfentry -DCC_USING_FENTRY -fno-inline-functions-called-once -fmin-function-alignment=16 -fstrict-flex-arrays=3 -fno-strict-overflow -fno-stack-check -fconserve-stack -fno-builtin-wcslen -Wall -Wextra -Wundef -Werror=implicit-function-declaration -Werror=implicit-int -Werror=return-type -Werror=strict-prototypes -Wno-format-security -Wno-trigraphs -Wno-frame-address -Wno-address-of-packed-member -Wmissing-declarations -Wmissing-prototypes -Wframe-larger-than=2048 -Wno-main -Wno-type-limits -Wno-dangling-pointer -Wvla-larger-than=1 -Wno-pointer-sign -Wcast-function-type -Wno-unterminated-string-initialization -Wno-array-bounds -Wno-stringop-overflow -Wno-alloc-size-larger-than -Wimplicit-fallthrough=5 -Werror=date-time -Werror=incompatible-pointer-types -Werror=designated-init -Wenum-conversion -Wunused -Wno-unused-but-set-variable -Wno-unused-const-variable -Wno-packed-not-aligned -Wno-format-overflow -Wno-format-truncation -Wno-stringop-truncation -Wno-override-init -Wno-missing-field-initializers -Wno-shift-negative-value -Wno-maybe-uninitialized -Wno-sign-compare -Wno-unused-parameter -g  -fsanitize=bounds-strict -fsanitize=shift    -DMODULE  -DKBUILD_BASENAME='"orion"' -DKBUILD_MODNAME='"orion"' -D__KBUILD_MODNAME=orion -c -o orion.o orion.c   ; /usr/src/kernels/7.1.3-200.fc44.x86_64/tools/objtool/objtool --hacks=jump_label --hacks=noinstr --hacks=skylake --ibt --orc --retpoline --rethunk --sls --static-call --uaccess --prefix=16  --link  --module orion.o

source_orion.o := orion.c

deps_orion.o := \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/compiler-version.h \
    $(wildcard include/config/CC_VERSION_TEXT) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/kconfig.h \
    $(wildcard include/config/CPU_BIG_ENDIAN) \
    $(wildcard include/config/BOOGER) \
    $(wildcard include/config/FOO) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/compiler_types.h \
    $(wildcard include/config/DEBUG_INFO_BTF) \
    $(wildcard include/config/PAHOLE_HAS_BTF_TAG) \
    $(wildcard include/config/FUNCTION_ALIGNMENT) \
    $(wildcard include/config/CC_HAS_SANE_FUNCTION_ALIGNMENT) \
    $(wildcard include/config/X86_64) \
    $(wildcard include/config/ARM64) \
    $(wildcard include/config/LD_DEAD_CODE_DATA_ELIMINATION) \
    $(wildcard include/config/LTO_CLANG) \
    $(wildcard include/config/HAVE_ARCH_COMPILER_H) \
    $(wildcard include/config/KCSAN) \
    $(wildcard include/config/CC_HAS_ASSUME) \
    $(wildcard include/config/CC_HAS_COUNTED_BY) \
    $(wildcard include/config/FORTIFY_SOURCE) \
    $(wildcard include/config/UBSAN_BOUNDS) \
    $(wildcard include/config/CC_HAS_COUNTED_BY_PTR) \
    $(wildcard include/config/CC_HAS_MULTIDIMENSIONAL_NONSTRING) \
    $(wildcard include/config/CFI) \
    $(wildcard include/config/ARCH_USES_CFI_GENERIC_LLVM_PASS) \
    $(wildcard include/config/CC_HAS_BROKEN_COUNTED_BY_REF) \
    $(wildcard include/config/CC_HAS_ASM_INLINE) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/compiler-context-analysis.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/compiler_attributes.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/compiler-gcc.h \
    $(wildcard include/config/ARCH_USE_BUILTIN_BSWAP) \
    $(wildcard include/config/SHADOW_CALL_STACK) \
    $(wildcard include/config/KCOV) \
    $(wildcard include/config/CC_HAS_TYPEOF_UNQUAL) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/init.h \
    $(wildcard include/config/MEMORY_HOTPLUG) \
    $(wildcard include/config/HAVE_ARCH_PREL32_RELOCATIONS) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/build_bug.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/compiler.h \
    $(wildcard include/config/TRACE_BRANCH_PROFILING) \
    $(wildcard include/config/PROFILE_ALL_BRANCHES) \
    $(wildcard include/config/OBJTOOL) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/arch/x86/include/generated/asm/rwonce.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/asm-generic/rwonce.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/kasan-checks.h \
    $(wildcard include/config/KASAN_GENERIC) \
    $(wildcard include/config/KASAN_SW_TAGS) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/types.h \
    $(wildcard include/config/HAVE_UID16) \
    $(wildcard include/config/UID16) \
    $(wildcard include/config/ARCH_DMA_ADDR_T_64BIT) \
    $(wildcard include/config/PHYS_ADDR_T_64BIT) \
    $(wildcard include/config/64BIT) \
    $(wildcard include/config/ARCH_32BIT_USTAT_F_TINODE) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/uapi/linux/types.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/arch/x86/include/generated/uapi/asm/types.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/uapi/asm-generic/types.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/asm-generic/int-ll64.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/uapi/asm-generic/int-ll64.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/arch/x86/include/uapi/asm/bitsperlong.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/asm-generic/bitsperlong.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/uapi/asm-generic/bitsperlong.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/uapi/linux/posix_types.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/stddef.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/uapi/linux/stddef.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/arch/x86/include/asm/posix_types.h \
    $(wildcard include/config/X86_32) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/arch/x86/include/uapi/asm/posix_types_64.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/uapi/asm-generic/posix_types.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/kcsan-checks.h \
    $(wildcard include/config/KCSAN_WEAK_MEMORY) \
    $(wildcard include/config/KCSAN_IGNORE_ATOMICS) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/stringify.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/module.h \
    $(wildcard include/config/MODULES) \
    $(wildcard include/config/SYSFS) \
    $(wildcard include/config/MODULES_TREE_LOOKUP) \
    $(wildcard include/config/LIVEPATCH) \
    $(wildcard include/config/STACKTRACE_BUILD_ID) \
    $(wildcard include/config/ARCH_USES_CFI_TRAPS) \
    $(wildcard include/config/MODULE_SIG) \
    $(wildcard include/config/GENERIC_BUG) \
    $(wildcard include/config/KALLSYMS) \
    $(wildcard include/config/SMP) \
    $(wildcard include/config/TRACEPOINTS) \
    $(wildcard include/config/TREE_SRCU) \
    $(wildcard include/config/BPF_EVENTS) \
    $(wildcard include/config/DEBUG_INFO_BTF_MODULES) \
    $(wildcard include/config/JUMP_LABEL) \
    $(wildcard include/config/TRACING) \
    $(wildcard include/config/EVENT_TRACING) \
    $(wildcard include/config/DYNAMIC_FTRACE) \
    $(wildcard include/config/KPROBES) \
    $(wildcard include/config/HAVE_STATIC_CALL_INLINE) \
    $(wildcard include/config/KUNIT) \
    $(wildcard include/config/PRINTK_INDEX) \
    $(wildcard include/config/MODULE_UNLOAD) \
    $(wildcard include/config/CONSTRUCTORS) \
    $(wildcard include/config/FUNCTION_ERROR_INJECTION) \
    $(wildcard include/config/DYNAMIC_DEBUG_CORE) \
    $(wildcard include/config/MITIGATION_RETPOLINE) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/list.h \
    $(wildcard include/config/LIST_HARDENED) \
    $(wildcard include/config/DEBUG_LIST) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/container_of.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/poison.h \
    $(wildcard include/config/ILLEGAL_POINTER_VALUE) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/const.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/vdso/const.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/uapi/linux/const.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/arch/x86/include/asm/barrier.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/arch/x86/include/asm/alternative.h \
    $(wildcard include/config/CALL_THUNKS) \
    $(wildcard include/config/MITIGATION_ITS) \
    $(wildcard include/config/MITIGATION_RETHUNK) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/objtool.h \
    $(wildcard include/config/FRAME_POINTER) \
    $(wildcard include/config/NOINSTR_VALIDATION) \
    $(wildcard include/config/MITIGATION_UNRET_ENTRY) \
    $(wildcard include/config/MITIGATION_SRSO) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/objtool_types.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/annotate.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/arch/x86/include/asm/asm.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/arch/x86/include/asm/asm-offsets.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/generated/asm-offsets.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/arch/x86/include/asm/extable_fixup_types.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/arch/x86/include/asm/bug.h \
    $(wildcard include/config/DEBUG_BUGVERBOSE) \
    $(wildcard include/config/DEBUG_BUGVERBOSE_DETAILED) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/instrumentation.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/static_call_types.h \
    $(wildcard include/config/HAVE_STATIC_CALL) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/asm-generic/bug.h \
    $(wildcard include/config/BUG) \
    $(wildcard include/config/GENERIC_BUG_RELATIVE_POINTERS) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/once_lite.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/panic.h \
    $(wildcard include/config/PANIC_TIMEOUT) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/stdarg.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/printk.h \
    $(wildcard include/config/MESSAGE_LOGLEVEL_DEFAULT) \
    $(wildcard include/config/CONSOLE_LOGLEVEL_DEFAULT) \
    $(wildcard include/config/CONSOLE_LOGLEVEL_QUIET) \
    $(wildcard include/config/EARLY_PRINTK) \
    $(wildcard include/config/PRINTK) \
    $(wildcard include/config/DYNAMIC_DEBUG) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/kern_levels.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/linkage.h \
    $(wildcard include/config/ARCH_USE_SYM_ANNOTATIONS) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/export.h \
    $(wildcard include/config/MODVERSIONS) \
    $(wildcard include/config/GENDWARFKSYMS) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/arch/x86/include/asm/linkage.h \
    $(wildcard include/config/CALL_PADDING) \
    $(wildcard include/config/MITIGATION_SLS) \
    $(wildcard include/config/FUNCTION_PADDING_BYTES) \
    $(wildcard include/config/UML) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/arch/x86/include/asm/ibt.h \
    $(wildcard include/config/X86_KERNEL_IBT) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/ratelimit_types.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/bits.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/vdso/bits.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/uapi/linux/bits.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/overflow.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/limits.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/uapi/linux/limits.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/vdso/limits.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/uapi/linux/param.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/arch/x86/include/generated/uapi/asm/param.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/asm-generic/param.h \
    $(wildcard include/config/HZ) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/uapi/asm-generic/param.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/spinlock_types_raw.h \
    $(wildcard include/config/DEBUG_SPINLOCK) \
    $(wildcard include/config/DEBUG_LOCK_ALLOC) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/arch/x86/include/asm/spinlock_types.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/asm-generic/qspinlock_types.h \
    $(wildcard include/config/NR_CPUS) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/asm-generic/qrwlock_types.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/arch/x86/include/uapi/asm/byteorder.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/byteorder/little_endian.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/uapi/linux/byteorder/little_endian.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/swab.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/uapi/linux/swab.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/arch/x86/include/uapi/asm/swab.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/byteorder/generic.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/lockdep_types.h \
    $(wildcard include/config/PROVE_RAW_LOCK_NESTING) \
    $(wildcard include/config/LOCKDEP) \
    $(wildcard include/config/LOCK_STAT) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/dynamic_debug.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/jump_label.h \
    $(wildcard include/config/HAVE_ARCH_JUMP_LABEL_RELATIVE) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/cleanup.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/err.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/arch/x86/include/generated/uapi/asm/errno.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/uapi/asm-generic/errno.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/uapi/asm-generic/errno-base.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/args.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/arch/x86/include/asm/jump_label.h \
    $(wildcard include/config/HAVE_JUMP_LABEL_HACK) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/arch/x86/include/asm/nops.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/asm-generic/barrier.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/stat.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/arch/x86/include/uapi/asm/stat.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/uapi/linux/stat.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/time.h \
    $(wildcard include/config/POSIX_TIMERS) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/cache.h \
    $(wildcard include/config/ARCH_HAS_CACHE_LINE_SIZE) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/uapi/linux/kernel.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/uapi/linux/sysinfo.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/vdso/cache.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/arch/x86/include/asm/cache.h \
    $(wildcard include/config/X86_L1_CACHE_SHIFT) \
    $(wildcard include/config/X86_INTERNODE_CACHE_SHIFT) \
    $(wildcard include/config/X86_VSMP) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/math64.h \
    $(wildcard include/config/ARCH_SUPPORTS_INT128) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/math.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/arch/x86/include/asm/div64.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/asm-generic/div64.h \
    $(wildcard include/config/CC_OPTIMIZE_FOR_PERFORMANCE) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/vdso/math64.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/time64.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/vdso/time64.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/uapi/linux/time.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/uapi/linux/time_types.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/time32.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/timex.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/uapi/linux/timex.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/arch/x86/include/asm/timex.h \
    $(wildcard include/config/X86_TSC) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/arch/x86/include/asm/processor.h \
    $(wildcard include/config/X86_VMX_FEATURE_NAMES) \
    $(wildcard include/config/X86_IOPL_IOPERM) \
    $(wildcard include/config/VM86) \
    $(wildcard include/config/X86_USER_SHADOW_STACK) \
    $(wildcard include/config/X86_DEBUG_FPU) \
    $(wildcard include/config/USE_X86_SEG_SUPPORT) \
    $(wildcard include/config/PARAVIRT_XXL) \
    $(wildcard include/config/CPU_SUP_AMD) \
    $(wildcard include/config/XEN) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/arch/x86/include/asm/processor-flags.h \
    $(wildcard include/config/MITIGATION_PAGE_TABLE_ISOLATION) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/arch/x86/include/uapi/asm/processor-flags.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/mem_encrypt.h \
    $(wildcard include/config/ARCH_HAS_MEM_ENCRYPT) \
    $(wildcard include/config/AMD_MEM_ENCRYPT) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/arch/x86/include/asm/mem_encrypt.h \
    $(wildcard include/config/X86_MEM_ENCRYPT) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/cc_platform.h \
    $(wildcard include/config/ARCH_HAS_CC_PLATFORM) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/arch/x86/include/asm/math_emu.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/arch/x86/include/asm/ptrace.h \
    $(wildcard include/config/PARAVIRT) \
    $(wildcard include/config/IA32_EMULATION) \
    $(wildcard include/config/X86_DEBUGCTLMSR) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/arch/x86/include/asm/segment.h \
    $(wildcard include/config/XEN_PV) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/arch/x86/include/asm/page_types.h \
    $(wildcard include/config/PHYSICAL_START) \
    $(wildcard include/config/PHYSICAL_ALIGN) \
    $(wildcard include/config/DYNAMIC_PHYSICAL_MASK) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/vdso/page.h \
    $(wildcard include/config/PAGE_SHIFT) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/arch/x86/include/asm/page_64_types.h \
    $(wildcard include/config/KASAN) \
    $(wildcard include/config/RANDOMIZE_BASE) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/arch/x86/include/asm/kaslr.h \
    $(wildcard include/config/RANDOMIZE_MEMORY) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/arch/x86/include/uapi/asm/ptrace.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/arch/x86/include/uapi/asm/ptrace-abi.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/arch/x86/include/asm/paravirt-base.h \
    $(wildcard include/config/PARAVIRT_SPINLOCKS) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/arch/x86/include/asm/proto.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/arch/x86/include/uapi/asm/ldt.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/arch/x86/include/uapi/asm/sigcontext.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/arch/x86/include/asm/current.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/arch/x86/include/asm/percpu.h \
    $(wildcard include/config/CC_HAS_NAMED_AS) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/asm-generic/percpu.h \
    $(wildcard include/config/DEBUG_PREEMPT) \
    $(wildcard include/config/HAVE_SETUP_PER_CPU_AREA) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/threads.h \
    $(wildcard include/config/BASE_SMALL) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/percpu-defs.h \
    $(wildcard include/config/ARCH_MODULE_NEEDS_WEAK_PER_CPU) \
    $(wildcard include/config/DEBUG_FORCE_WEAK_PER_CPU) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/arch/x86/include/asm/cpufeatures.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/arch/x86/include/asm/cpuid/api.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/arch/x86/include/asm/cpuid/types.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/arch/x86/include/asm/string.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/arch/x86/include/asm/string_64.h \
    $(wildcard include/config/KMSAN) \
    $(wildcard include/config/ARCH_HAS_UACCESS_FLUSHCACHE) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/arch/x86/include/asm/paravirt.h \
    $(wildcard include/config/DEBUG_ENTRY) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/arch/x86/include/asm/paravirt_types.h \
    $(wildcard include/config/ZERO_CALL_USED_REGS) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/arch/x86/include/asm/desc_defs.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/arch/x86/include/asm/pgtable_types.h \
    $(wildcard include/config/X86_INTEL_MEMORY_PROTECTION_KEYS) \
    $(wildcard include/config/X86_PAE) \
    $(wildcard include/config/MEM_SOFT_DIRTY) \
    $(wildcard include/config/HAVE_ARCH_USERFAULTFD_WP) \
    $(wildcard include/config/PGTABLE_LEVELS) \
    $(wildcard include/config/PROC_FS) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/arch/x86/include/asm/pgtable_64_types.h \
    $(wildcard include/config/DEBUG_KMAP_LOCAL_FORCE_MAP) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/arch/x86/include/asm/sparsemem.h \
    $(wildcard include/config/SPARSEMEM) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/arch/x86/include/asm/nospec-branch.h \
    $(wildcard include/config/CALL_THUNKS_DEBUG) \
    $(wildcard include/config/MITIGATION_CALL_DEPTH_TRACKING) \
    $(wildcard include/config/MITIGATION_IBPB_ENTRY) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/static_key.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/arch/x86/include/asm/msr-index.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/arch/x86/include/asm/unwind_hints.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/arch/x86/include/asm/orc_types.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/arch/x86/include/asm/GEN-for-each-reg.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/cpumask.h \
    $(wildcard include/config/FORCE_NR_CPUS) \
    $(wildcard include/config/HOTPLUG_CPU) \
    $(wildcard include/config/DEBUG_PER_CPU_MAPS) \
    $(wildcard include/config/CPUMASK_OFFSTACK) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/atomic.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/arch/x86/include/asm/atomic.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/arch/x86/include/asm/cmpxchg.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/arch/x86/include/asm/cmpxchg_64.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/arch/x86/include/asm/rmwcc.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/arch/x86/include/asm/atomic64_64.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/atomic/atomic-arch-fallback.h \
    $(wildcard include/config/GENERIC_ATOMIC64) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/atomic/atomic-long.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/atomic/atomic-instrumented.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/instrumented.h \
    $(wildcard include/config/DEBUG_ATOMIC) \
    $(wildcard include/config/DEBUG_ATOMIC_LARGEST_ALIGN) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/bug.h \
    $(wildcard include/config/BUG_ON_DATA_CORRUPTION) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/kmsan-checks.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/bitmap.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/align.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/vdso/align.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/bitops.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/typecheck.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/asm-generic/bitops/generic-non-atomic.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/arch/x86/include/asm/bitops.h \
    $(wildcard include/config/X86_CMOV) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/asm-generic/bitops/sched.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/arch/x86/include/asm/arch_hweight.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/asm-generic/bitops/const_hweight.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/asm-generic/bitops/instrumented-atomic.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/asm-generic/bitops/instrumented-non-atomic.h \
    $(wildcard include/config/KCSAN_ASSUME_PLAIN_WRITES_ATOMIC) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/asm-generic/bitops/instrumented-lock.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/asm-generic/bitops/le.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/asm-generic/bitops/ext2-atomic-setbit.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/errno.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/uapi/linux/errno.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/find.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/string.h \
    $(wildcard include/config/BINARY_PRINTF) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/array_size.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/uapi/linux/string.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/fortify-string.h \
    $(wildcard include/config/CC_HAS_KASAN_MEMINTRINSIC_PREFIX) \
    $(wildcard include/config/GENERIC_ENTRY) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/bitmap-str.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/cpumask_types.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/gfp_types.h \
    $(wildcard include/config/KASAN_HW_TAGS) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/numa.h \
    $(wildcard include/config/NUMA_KEEP_MEMINFO) \
    $(wildcard include/config/NUMA) \
    $(wildcard include/config/HAVE_ARCH_NODE_DEV_GROUP) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/nodemask.h \
    $(wildcard include/config/HIGHMEM) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/minmax.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/nodemask_types.h \
    $(wildcard include/config/NODES_SHIFT) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/random.h \
    $(wildcard include/config/VMGENID) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/kernel.h \
    $(wildcard include/config/PREEMPT_VOLUNTARY_BUILD) \
    $(wildcard include/config/PREEMPT_DYNAMIC) \
    $(wildcard include/config/HAVE_PREEMPT_DYNAMIC_CALL) \
    $(wildcard include/config/HAVE_PREEMPT_DYNAMIC_KEY) \
    $(wildcard include/config/PREEMPT_) \
    $(wildcard include/config/DEBUG_ATOMIC_SLEEP) \
    $(wildcard include/config/MMU) \
    $(wildcard include/config/PROVE_LOCKING) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/kstrtox.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/log2.h \
    $(wildcard include/config/ARCH_HAS_ILOG2_U32) \
    $(wildcard include/config/ARCH_HAS_ILOG2_U64) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/sprintf.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/trace_printk.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/instruction_pointer.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/util_macros.h \
    $(wildcard include/config/FOO_SUSPEND) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/wordpart.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/uapi/linux/random.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/uapi/linux/ioctl.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/arch/x86/include/generated/uapi/asm/ioctl.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/asm-generic/ioctl.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/uapi/asm-generic/ioctl.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/irqnr.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/uapi/linux/irqnr.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/arch/x86/include/asm/frame.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/arch/x86/include/asm/page.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/arch/x86/include/asm/page_64.h \
    $(wildcard include/config/DEBUG_VIRTUAL) \
    $(wildcard include/config/X86_VSYSCALL_EMULATION) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/mmdebug.h \
    $(wildcard include/config/DEBUG_VM) \
    $(wildcard include/config/DEBUG_VM_IRQSOFF) \
    $(wildcard include/config/DEBUG_VM_PGFLAGS) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/range.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/asm-generic/memory_model.h \
    $(wildcard include/config/FLATMEM) \
    $(wildcard include/config/SPARSEMEM_VMEMMAP) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/pfn.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/asm-generic/getorder.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/arch/x86/include/asm/special_insns.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/irqflags.h \
    $(wildcard include/config/TRACE_IRQFLAGS) \
    $(wildcard include/config/PREEMPT_RT) \
    $(wildcard include/config/IRQSOFF_TRACER) \
    $(wildcard include/config/PREEMPT_TRACER) \
    $(wildcard include/config/DEBUG_IRQFLAGS) \
    $(wildcard include/config/TRACE_IRQFLAGS_SUPPORT) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/irqflags_types.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/arch/x86/include/asm/irqflags.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/arch/x86/include/asm/fpu/types.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/arch/x86/include/asm/vmxfeatures.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/arch/x86/include/asm/vdso/processor.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/arch/x86/include/asm/shstk.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/personality.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/uapi/linux/personality.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/arch/x86/include/asm/tsc.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/arch/x86/include/asm/cpufeature.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/arch/x86/include/generated/asm/cpufeaturemasks.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/arch/x86/include/asm/msr.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/arch/x86/include/asm/cpumask.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/arch/x86/include/uapi/asm/msr.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/arch/x86/include/asm/shared/msr.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/percpu.h \
    $(wildcard include/config/RANDOM_KMALLOC_CACHES) \
    $(wildcard include/config/PAGE_SIZE_4KB) \
    $(wildcard include/config/NEED_PER_CPU_PAGE_FIRST_CHUNK) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/alloc_tag.h \
    $(wildcard include/config/MEM_ALLOC_PROFILING_DEBUG) \
    $(wildcard include/config/MEM_ALLOC_PROFILING) \
    $(wildcard include/config/MEM_ALLOC_PROFILING_ENABLED_BY_DEFAULT) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/codetag.h \
    $(wildcard include/config/CODE_TAGGING) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/preempt.h \
    $(wildcard include/config/PREEMPT_COUNT) \
    $(wildcard include/config/TRACE_PREEMPT_TOGGLE) \
    $(wildcard include/config/PREEMPTION) \
    $(wildcard include/config/PREEMPT_NOTIFIERS) \
    $(wildcard include/config/PREEMPT_NONE) \
    $(wildcard include/config/PREEMPT_VOLUNTARY) \
    $(wildcard include/config/PREEMPT) \
    $(wildcard include/config/PREEMPT_LAZY) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/arch/x86/include/asm/preempt.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/smp.h \
    $(wildcard include/config/UP_LATE_INIT) \
    $(wildcard include/config/CSD_LOCK_WAIT_DEBUG) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/smp_types.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/llist.h \
    $(wildcard include/config/ARCH_HAVE_NMI_SAFE_CMPXCHG) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/thread_info.h \
    $(wildcard include/config/THREAD_INFO_IN_TASK) \
    $(wildcard include/config/ARCH_HAS_PREEMPT_LAZY) \
    $(wildcard include/config/HAVE_ARCH_WITHIN_STACK_FRAMES) \
    $(wildcard include/config/SH) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/restart_block.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/arch/x86/include/asm/thread_info.h \
    $(wildcard include/config/X86_FRED) \
    $(wildcard include/config/COMPAT) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/asm-generic/thread_info_tif.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/arch/x86/include/asm/smp.h \
    $(wildcard include/config/DEBUG_NMI_SELFTEST) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/sched.h \
    $(wildcard include/config/VIRT_CPU_ACCOUNTING_NATIVE) \
    $(wildcard include/config/SCHED_INFO) \
    $(wildcard include/config/SCHEDSTATS) \
    $(wildcard include/config/SCHED_CORE) \
    $(wildcard include/config/FAIR_GROUP_SCHED) \
    $(wildcard include/config/RT_GROUP_SCHED) \
    $(wildcard include/config/RT_MUTEXES) \
    $(wildcard include/config/UCLAMP_TASK) \
    $(wildcard include/config/UCLAMP_BUCKETS_COUNT) \
    $(wildcard include/config/KMAP_LOCAL) \
    $(wildcard include/config/SCHED_CLASS_EXT) \
    $(wildcard include/config/CGROUP_SCHED) \
    $(wildcard include/config/CFS_BANDWIDTH) \
    $(wildcard include/config/BLK_DEV_IO_TRACE) \
    $(wildcard include/config/PREEMPT_RCU) \
    $(wildcard include/config/TASKS_RCU) \
    $(wildcard include/config/TASKS_TRACE_RCU) \
    $(wildcard include/config/TRIVIAL_PREEMPT_RCU) \
    $(wildcard include/config/MEMCG_V1) \
    $(wildcard include/config/LRU_GEN) \
    $(wildcard include/config/COMPAT_BRK) \
    $(wildcard include/config/CGROUPS) \
    $(wildcard include/config/BLK_CGROUP) \
    $(wildcard include/config/PSI) \
    $(wildcard include/config/PAGE_OWNER) \
    $(wildcard include/config/EVENTFD) \
    $(wildcard include/config/ARCH_HAS_CPU_PASID) \
    $(wildcard include/config/X86_BUS_LOCK_DETECT) \
    $(wildcard include/config/TASK_DELAY_ACCT) \
    $(wildcard include/config/STACKPROTECTOR) \
    $(wildcard include/config/ARCH_HAS_SCALED_CPUTIME) \
    $(wildcard include/config/VIRT_CPU_ACCOUNTING_GEN) \
    $(wildcard include/config/NO_HZ_FULL) \
    $(wildcard include/config/POSIX_CPUTIMERS) \
    $(wildcard include/config/POSIX_CPU_TIMERS_TASK_WORK) \
    $(wildcard include/config/KEYS) \
    $(wildcard include/config/SYSVIPC) \
    $(wildcard include/config/DETECT_HUNG_TASK) \
    $(wildcard include/config/IO_URING) \
    $(wildcard include/config/AUDIT) \
    $(wildcard include/config/AUDITSYSCALL) \
    $(wildcard include/config/DETECT_HUNG_TASK_BLOCKER) \
    $(wildcard include/config/UBSAN) \
    $(wildcard include/config/UBSAN_TRAP) \
    $(wildcard include/config/COMPACTION) \
    $(wildcard include/config/TASK_XACCT) \
    $(wildcard include/config/CPUSETS) \
    $(wildcard include/config/X86_CPU_RESCTRL) \
    $(wildcard include/config/FUTEX) \
    $(wildcard include/config/PERF_EVENTS) \
    $(wildcard include/config/NUMA_BALANCING) \
    $(wildcard include/config/ARCH_HAS_LAZY_MMU_MODE) \
    $(wildcard include/config/FAULT_INJECTION) \
    $(wildcard include/config/LATENCYTOP) \
    $(wildcard include/config/FUNCTION_GRAPH_TRACER) \
    $(wildcard include/config/MEMCG) \
    $(wildcard include/config/UPROBES) \
    $(wildcard include/config/BCACHE) \
    $(wildcard include/config/VMAP_STACK) \
    $(wildcard include/config/SECURITY) \
    $(wildcard include/config/BPF_SYSCALL) \
    $(wildcard include/config/KSTACK_ERASE) \
    $(wildcard include/config/KSTACK_ERASE_METRICS) \
    $(wildcard include/config/X86_MCE) \
    $(wildcard include/config/KRETPROBES) \
    $(wildcard include/config/RETHOOK) \
    $(wildcard include/config/ARCH_HAS_PARANOID_L1D_FLUSH) \
    $(wildcard include/config/RV) \
    $(wildcard include/config/RV_PER_TASK_MONITORS) \
    $(wildcard include/config/USER_EVENTS) \
    $(wildcard include/config/UNWIND_USER) \
    $(wildcard include/config/SCHED_PROXY_EXEC) \
    $(wildcard include/config/SCHED_MM_CID) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/uapi/linux/sched.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/pid_types.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/sem_types.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/shm.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/arch/x86/include/asm/shmparam.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/kmsan_types.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/mutex_types.h \
    $(wildcard include/config/MUTEX_SPIN_ON_OWNER) \
    $(wildcard include/config/DEBUG_MUTEXES) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/osq_lock.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/spinlock_types.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/rwlock_types.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/plist_types.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/hrtimer_types.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/timerqueue_types.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/rbtree_types.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/timer_types.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/seccomp_types.h \
    $(wildcard include/config/SECCOMP) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/refcount_types.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/resource.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/uapi/linux/resource.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/arch/x86/include/generated/uapi/asm/resource.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/asm-generic/resource.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/uapi/asm-generic/resource.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/latencytop.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/sched/prio.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/sched/types.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/signal_types.h \
    $(wildcard include/config/OLD_SIGACTION) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/uapi/linux/signal.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/arch/x86/include/asm/signal.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/arch/x86/include/uapi/asm/signal.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/uapi/asm-generic/signal-defs.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/arch/x86/include/uapi/asm/siginfo.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/uapi/asm-generic/siginfo.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/spinlock.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/bottom_half.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/lockdep.h \
    $(wildcard include/config/DEBUG_LOCKING_API_SELFTESTS) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/arch/x86/include/generated/asm/mmiowb.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/asm-generic/mmiowb.h \
    $(wildcard include/config/MMIOWB) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/arch/x86/include/asm/spinlock.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/arch/x86/include/asm/qspinlock.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/arch/x86/include/asm/paravirt-spinlock.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/asm-generic/qspinlock.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/arch/x86/include/asm/qrwlock.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/asm-generic/qrwlock.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/rwlock.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/spinlock_api_smp.h \
    $(wildcard include/config/INLINE_SPIN_LOCK) \
    $(wildcard include/config/INLINE_SPIN_LOCK_BH) \
    $(wildcard include/config/INLINE_SPIN_LOCK_IRQ) \
    $(wildcard include/config/INLINE_SPIN_LOCK_IRQSAVE) \
    $(wildcard include/config/INLINE_SPIN_TRYLOCK) \
    $(wildcard include/config/INLINE_SPIN_TRYLOCK_BH) \
    $(wildcard include/config/UNINLINE_SPIN_UNLOCK) \
    $(wildcard include/config/INLINE_SPIN_UNLOCK_BH) \
    $(wildcard include/config/INLINE_SPIN_UNLOCK_IRQ) \
    $(wildcard include/config/INLINE_SPIN_UNLOCK_IRQRESTORE) \
    $(wildcard include/config/GENERIC_LOCKBREAK) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/rwlock_api_smp.h \
    $(wildcard include/config/INLINE_READ_LOCK) \
    $(wildcard include/config/INLINE_WRITE_LOCK) \
    $(wildcard include/config/INLINE_READ_LOCK_BH) \
    $(wildcard include/config/INLINE_WRITE_LOCK_BH) \
    $(wildcard include/config/INLINE_READ_LOCK_IRQ) \
    $(wildcard include/config/INLINE_WRITE_LOCK_IRQ) \
    $(wildcard include/config/INLINE_READ_LOCK_IRQSAVE) \
    $(wildcard include/config/INLINE_WRITE_LOCK_IRQSAVE) \
    $(wildcard include/config/INLINE_READ_TRYLOCK) \
    $(wildcard include/config/INLINE_WRITE_TRYLOCK) \
    $(wildcard include/config/INLINE_READ_UNLOCK) \
    $(wildcard include/config/INLINE_WRITE_UNLOCK) \
    $(wildcard include/config/INLINE_READ_UNLOCK_BH) \
    $(wildcard include/config/INLINE_WRITE_UNLOCK_BH) \
    $(wildcard include/config/INLINE_READ_UNLOCK_IRQ) \
    $(wildcard include/config/INLINE_WRITE_UNLOCK_IRQ) \
    $(wildcard include/config/INLINE_READ_UNLOCK_IRQRESTORE) \
    $(wildcard include/config/INLINE_WRITE_UNLOCK_IRQRESTORE) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/syscall_user_dispatch_types.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/mm_types_task.h \
    $(wildcard include/config/ARCH_WANT_BATCHED_UNMAP_TLB_FLUSH) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/arch/x86/include/asm/tlbbatch.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/netdevice_xmit.h \
    $(wildcard include/config/NET_ACT_MIRRED) \
    $(wildcard include/config/NET_EGRESS) \
    $(wildcard include/config/NF_DUP_NETDEV) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/task_io_accounting.h \
    $(wildcard include/config/TASK_IO_ACCOUNTING) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/posix-timers_types.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/rseq_types.h \
    $(wildcard include/config/RSEQ) \
    $(wildcard include/config/RSEQ_SLICE_EXTENSION) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/irq_work_types.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/workqueue_types.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/seqlock_types.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/kcsan.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/rv.h \
    $(wildcard include/config/RV_LTL_MONITOR) \
    $(wildcard include/config/RV_HA_MONITOR) \
    $(wildcard include/config/RV_REACTORS) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/uidgid_types.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/tracepoint-defs.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/unwind_deferred_types.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/arch/x86/include/generated/asm/kmap_size.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/asm-generic/kmap_size.h \
    $(wildcard include/config/DEBUG_KMAP_LOCAL) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/generated/rq-offsets.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/sched/ext.h \
    $(wildcard include/config/EXT_GROUP_SCHED) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/rhashtable-types.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/mutex.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/debug_locks.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/vdso/time32.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/vdso/time.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/uidgid.h \
    $(wildcard include/config/MULTIUSER) \
    $(wildcard include/config/USER_NS) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/highuid.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/buildid.h \
    $(wildcard include/config/VMCORE_INFO) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/kmod.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/umh.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/gfp.h \
    $(wildcard include/config/ZONE_DMA) \
    $(wildcard include/config/ZONE_DMA32) \
    $(wildcard include/config/ZONE_DEVICE) \
    $(wildcard include/config/CONTIG_ALLOC) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/mmzone.h \
    $(wildcard include/config/ARCH_FORCE_MAX_ORDER) \
    $(wildcard include/config/PAGE_BLOCK_MAX_ORDER) \
    $(wildcard include/config/HAVE_GIGANTIC_FOLIOS) \
    $(wildcard include/config/HUGETLB_PAGE) \
    $(wildcard include/config/HUGETLB_PAGE_OPTIMIZE_VMEMMAP) \
    $(wildcard include/config/CMA) \
    $(wildcard include/config/MEMORY_ISOLATION) \
    $(wildcard include/config/ZSMALLOC) \
    $(wildcard include/config/UNACCEPTED_MEMORY) \
    $(wildcard include/config/IOMMU_SUPPORT) \
    $(wildcard include/config/SWAP) \
    $(wildcard include/config/TRANSPARENT_HUGEPAGE) \
    $(wildcard include/config/LRU_GEN_STATS) \
    $(wildcard include/config/LRU_GEN_WALKS_MMU) \
    $(wildcard include/config/MEMORY_FAILURE) \
    $(wildcard include/config/PAGE_EXTENSION) \
    $(wildcard include/config/DEFERRED_STRUCT_PAGE_INIT) \
    $(wildcard include/config/HAVE_MEMORYLESS_NODES) \
    $(wildcard include/config/SPARSEMEM_EXTREME) \
    $(wildcard include/config/SPARSEMEM_VMEMMAP_PREINIT) \
    $(wildcard include/config/HAVE_ARCH_PFN_VALID) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/list_nulls.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/wait.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/seqlock.h \
    $(wildcard include/config/CC_IS_GCC) \
    $(wildcard include/config/GCC_VERSION) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/pageblock-flags.h \
    $(wildcard include/config/HUGETLB_PAGE_SIZE_VARIABLE) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/page-flags-layout.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/generated/bounds.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/mm_types.h \
    $(wildcard include/config/HAVE_ALIGNED_STRUCT_PAGE) \
    $(wildcard include/config/SLAB_OBJ_EXT) \
    $(wildcard include/config/HUGETLB_PMD_PAGE_TABLE_SHARING) \
    $(wildcard include/config/SLAB_FREELIST_HARDENED) \
    $(wildcard include/config/USERFAULTFD) \
    $(wildcard include/config/ANON_VMA_NAME) \
    $(wildcard include/config/PER_VMA_LOCK) \
    $(wildcard include/config/HAVE_ARCH_COMPAT_MMAP_BASES) \
    $(wildcard include/config/MEMBARRIER) \
    $(wildcard include/config/FUTEX_PRIVATE_HASH) \
    $(wildcard include/config/ARCH_HAS_ELF_CORE_EFLAGS) \
    $(wildcard include/config/AIO) \
    $(wildcard include/config/MMU_NOTIFIER) \
    $(wildcard include/config/SPLIT_PMD_PTLOCKS) \
    $(wildcard include/config/IOMMU_MM_DATA) \
    $(wildcard include/config/KSM) \
    $(wildcard include/config/MM_ID) \
    $(wildcard include/config/CORE_DUMP_DEFAULT_ELF_HEADERS) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/auxvec.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/uapi/linux/auxvec.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/arch/x86/include/uapi/asm/auxvec.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/kref.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/refcount.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/rbtree.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/rcupdate.h \
    $(wildcard include/config/TINY_RCU) \
    $(wildcard include/config/RCU_STRICT_GRACE_PERIOD) \
    $(wildcard include/config/RCU_LAZY) \
    $(wildcard include/config/RCU_STALL_COMMON) \
    $(wildcard include/config/VIRT_XFER_TO_GUEST_WORK) \
    $(wildcard include/config/RCU_NOCB_CPU) \
    $(wildcard include/config/TASKS_RCU_GENERIC) \
    $(wildcard include/config/TASKS_RUDE_RCU) \
    $(wildcard include/config/TREE_RCU) \
    $(wildcard include/config/DEBUG_OBJECTS_RCU_HEAD) \
    $(wildcard include/config/PROVE_RCU) \
    $(wildcard include/config/ARCH_WEAK_RELEASE_ACQUIRE) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/context_tracking_irq.h \
    $(wildcard include/config/CONTEXT_TRACKING_IDLE) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/rcutree.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/maple_tree.h \
    $(wildcard include/config/MAPLE_RCU_DISABLED) \
    $(wildcard include/config/DEBUG_MAPLE_TREE) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/rwsem.h \
    $(wildcard include/config/RWSEM_SPIN_ON_OWNER) \
    $(wildcard include/config/DEBUG_RWSEMS) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/completion.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/swait.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/uprobes.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/timer.h \
    $(wildcard include/config/DEBUG_OBJECTS_TIMERS) \
    $(wildcard include/config/NO_HZ_COMMON) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/ktime.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/jiffies.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/vdso/jiffies.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/generated/timeconst.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/vdso/ktime.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/timekeeping.h \
    $(wildcard include/config/POSIX_AUX_CLOCKS) \
    $(wildcard include/config/GENERIC_CMOS_UPDATE) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/clocksource_ids.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/debugobjects.h \
    $(wildcard include/config/DEBUG_OBJECTS) \
    $(wildcard include/config/DEBUG_OBJECTS_FREE) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/arch/x86/include/asm/uprobes.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/notifier.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/srcu.h \
    $(wildcard include/config/TINY_SRCU) \
    $(wildcard include/config/NEED_SRCU_NMI_SAFE) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/workqueue.h \
    $(wildcard include/config/DEBUG_OBJECTS_WORK) \
    $(wildcard include/config/FREEZER) \
    $(wildcard include/config/WQ_WATCHDOG) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/rcu_segcblist.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/srcutree.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/rcu_node_tree.h \
    $(wildcard include/config/RCU_FANOUT) \
    $(wildcard include/config/RCU_FANOUT_LEAF) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/percpu_counter.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/arch/x86/include/asm/mmu.h \
    $(wildcard include/config/MODIFY_LDT_SYSCALL) \
    $(wildcard include/config/ADDRESS_MASKING) \
    $(wildcard include/config/BROADCAST_TLB_FLUSH) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/page-flags.h \
    $(wildcard include/config/PAGE_IDLE_FLAG) \
    $(wildcard include/config/ARCH_USES_PG_ARCH_2) \
    $(wildcard include/config/ARCH_USES_PG_ARCH_3) \
    $(wildcard include/config/MIGRATION) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/local_lock.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/local_lock_internal.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/zswap.h \
    $(wildcard include/config/ZSWAP) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/sizes.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/memory_hotplug.h \
    $(wildcard include/config/ARCH_HAS_ADD_PAGES) \
    $(wildcard include/config/MEMORY_HOTREMOVE) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/arch/x86/include/generated/asm/mmzone.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/asm-generic/mmzone.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/topology.h \
    $(wildcard include/config/USE_PERCPU_NUMA_NODE_ID) \
    $(wildcard include/config/SCHED_SMT) \
    $(wildcard include/config/GENERIC_ARCH_TOPOLOGY) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/arch_topology.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/arch/x86/include/asm/topology.h \
    $(wildcard include/config/X86_LOCAL_APIC) \
    $(wildcard include/config/SCHED_MC_PRIO) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/arch/x86/include/asm/mpspec.h \
    $(wildcard include/config/EISA) \
    $(wildcard include/config/X86_MPPARSE) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/arch/x86/include/asm/mpspec_def.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/arch/x86/include/asm/x86_init.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/arch/x86/include/asm/apicdef.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/asm-generic/topology.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/cpu_smt.h \
    $(wildcard include/config/HOTPLUG_SMT) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/sysctl.h \
    $(wildcard include/config/SYSCTL) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/uapi/linux/sysctl.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/elf.h \
    $(wildcard include/config/ARCH_HAVE_EXTRA_ELF_NOTES) \
    $(wildcard include/config/ARCH_USE_GNU_PROPERTY) \
    $(wildcard include/config/ARCH_HAVE_ELF_PROT) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/arch/x86/include/asm/elf.h \
    $(wildcard include/config/X86_X32_ABI) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/arch/x86/include/asm/ia32.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/compat.h \
    $(wildcard include/config/ARCH_HAS_SYSCALL_WRAPPER) \
    $(wildcard include/config/COMPAT_OLD_SIGACTION) \
    $(wildcard include/config/HARDENED_USERCOPY) \
    $(wildcard include/config/ODD_RT_SIGACTION) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/sem.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/uapi/linux/sem.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/ipc.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/uapi/linux/ipc.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/arch/x86/include/generated/uapi/asm/ipcbuf.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/uapi/asm-generic/ipcbuf.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/arch/x86/include/uapi/asm/sembuf.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/socket.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/arch/x86/include/generated/uapi/asm/socket.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/uapi/asm-generic/socket.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/arch/x86/include/generated/uapi/asm/sockios.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/uapi/asm-generic/sockios.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/uapi/linux/sockios.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/uio.h \
    $(wildcard include/config/ARCH_HAS_COPY_MC) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/ucopysize.h \
    $(wildcard include/config/HARDENED_USERCOPY_DEFAULT_ON) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/uapi/linux/uio.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/uapi/linux/socket.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/uapi/linux/if.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/uapi/linux/libc-compat.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/uapi/linux/hdlc/ioctl.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/fs.h \
    $(wildcard include/config/FANOTIFY_ACCESS_PERMISSIONS) \
    $(wildcard include/config/READ_ONLY_THP_FOR_FS) \
    $(wildcard include/config/FS_POSIX_ACL) \
    $(wildcard include/config/CGROUP_WRITEBACK) \
    $(wildcard include/config/IMA) \
    $(wildcard include/config/FILE_LOCKING) \
    $(wildcard include/config/FSNOTIFY) \
    $(wildcard include/config/EPOLL) \
    $(wildcard include/config/FS_DAX) \
    $(wildcard include/config/BLOCK) \
    $(wildcard include/config/UNICODE) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/fs/super.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/fs/super_types.h \
    $(wildcard include/config/QUOTA) \
    $(wildcard include/config/FS_ENCRYPTION) \
    $(wildcard include/config/FS_VERITY) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/fs_dirent.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/errseq.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/list_lru.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/shrinker.h \
    $(wildcard include/config/SHRINKER_DEBUG) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/xarray.h \
    $(wildcard include/config/XARRAY_MULTI) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/sched/mm.h \
    $(wildcard include/config/MMU_LAZY_TLB_REFCOUNT) \
    $(wildcard include/config/ARCH_HAS_MEMBARRIER_CALLBACKS) \
    $(wildcard include/config/ARCH_HAS_SYNC_CORE_BEFORE_USERMODE) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/sync_core.h \
    $(wildcard include/config/ARCH_HAS_PREPARE_SYNC_CORE_CMD) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/arch/x86/include/asm/sync_core.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/sched/coredump.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/list_bl.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/bit_spinlock.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/uuid.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/percpu-rwsem.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/rcuwait.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/sched/signal.h \
    $(wildcard include/config/SCHED_AUTOGROUP) \
    $(wildcard include/config/BSD_PROCESS_ACCT) \
    $(wildcard include/config/TASKSTATS) \
    $(wildcard include/config/STACK_GROWSUP) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/rculist.h \
    $(wildcard include/config/PROVE_RCU_LIST) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/signal.h \
    $(wildcard include/config/DYNAMIC_SIGFRAME) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/sched/jobctl.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/sched/task.h \
    $(wildcard include/config/HAVE_EXIT_THREAD) \
    $(wildcard include/config/ARCH_WANTS_DYNAMIC_TASK_STRUCT) \
    $(wildcard include/config/HAVE_ARCH_THREAD_STRUCT_WHITELIST) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/uaccess.h \
    $(wildcard include/config/ARCH_HAS_SUBPAGE_FAULTS) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/fault-inject-usercopy.h \
    $(wildcard include/config/FAULT_INJECTION_USERCOPY) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/nospec.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/arch/x86/include/asm/uaccess.h \
    $(wildcard include/config/CC_HAS_ASM_GOTO_OUTPUT) \
    $(wildcard include/config/CC_HAS_ASM_GOTO_TIED_OUTPUT) \
    $(wildcard include/config/X86_INTEL_USERCOPY) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/mmap_lock.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/arch/x86/include/asm/smap.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/arch/x86/include/asm/extable.h \
    $(wildcard include/config/BPF_JIT) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/arch/x86/include/asm/tlbflush.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/mmu_notifier.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/interval_tree.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/arch/x86/include/asm/invpcid.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/arch/x86/include/asm/pti.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/arch/x86/include/asm/pgtable.h \
    $(wildcard include/config/DEBUG_WX) \
    $(wildcard include/config/HAVE_ARCH_TRANSPARENT_HUGEPAGE_PUD) \
    $(wildcard include/config/ARCH_SUPPORTS_PMD_PFNMAP) \
    $(wildcard include/config/ARCH_SUPPORTS_PUD_PFNMAP) \
    $(wildcard include/config/HAVE_ARCH_SOFT_DIRTY) \
    $(wildcard include/config/ARCH_ENABLE_THP_MIGRATION) \
    $(wildcard include/config/PAGE_TABLE_CHECK) \
    $(wildcard include/config/X86_SGX) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/arch/x86/include/asm/pkru.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/arch/x86/include/asm/fpu/api.h \
    $(wildcard include/config/MATH_EMULATION) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/arch/x86/include/asm/coco.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/asm-generic/pgtable_uffd.h \
    $(wildcard include/config/PTE_MARKER_UFFD_WP) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/page_table_check.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/arch/x86/include/asm/pgtable_64.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/arch/x86/include/asm/fixmap.h \
    $(wildcard include/config/PROVIDE_OHCI1394_DMA_INIT) \
    $(wildcard include/config/X86_IO_APIC) \
    $(wildcard include/config/PCI_MMCONFIG) \
    $(wildcard include/config/ACPI_APEI_GHES) \
    $(wildcard include/config/INTEL_TXT) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/arch/x86/include/uapi/asm/vsyscall.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/asm-generic/fixmap.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/arch/x86/include/asm/pgtable-invert.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/arch/x86/include/asm/uaccess_64.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/asm-generic/access_ok.h \
    $(wildcard include/config/ALTERNATE_USER_ADDRESS_SPACE) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/cred.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/capability.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/uapi/linux/capability.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/key.h \
    $(wildcard include/config/KEY_NOTIFICATIONS) \
    $(wildcard include/config/NET) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/assoc_array.h \
    $(wildcard include/config/ASSOCIATIVE_ARRAY) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/sched/user.h \
    $(wildcard include/config/VFIO_PCI_ZDEV_KVM) \
    $(wildcard include/config/IOMMUFD) \
    $(wildcard include/config/WATCH_QUEUE) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/ratelimit.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/pid.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/posix-timers.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/alarmtimer.h \
    $(wildcard include/config/RTC_CLASS) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/hrtimer.h \
    $(wildcard include/config/HIGH_RES_TIMERS) \
    $(wildcard include/config/TIME_LOW_RES) \
    $(wildcard include/config/TIMERFD) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/hrtimer_defs.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/timerqueue.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/hrtimer_rearm.h \
    $(wildcard include/config/HRTIMER_REARM_DEFERRED) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/rcuref.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/rcu_sync.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/quota.h \
    $(wildcard include/config/QUOTA_NETLINK_INTERFACE) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/uapi/linux/dqblk_xfs.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/dqblk_v1.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/dqblk_v2.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/dqblk_qtree.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/projid.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/uapi/linux/quota.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/unicode.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/dcache.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/rculist_bl.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/lockref.h \
    $(wildcard include/config/ARCH_USE_CMPXCHG_LOCKREF) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/stringhash.h \
    $(wildcard include/config/DCACHE_WORD_ACCESS) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/hash.h \
    $(wildcard include/config/HAVE_ARCH_HASH) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/vfsdebug.h \
    $(wildcard include/config/DEBUG_VFS) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/wait_bit.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/kdev_t.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/uapi/linux/kdev_t.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/path.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/radix-tree.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/semaphore.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/fcntl.h \
    $(wildcard include/config/ARCH_32BIT_OFF_T) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/uapi/linux/fcntl.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/arch/x86/include/generated/uapi/asm/fcntl.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/uapi/asm-generic/fcntl.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/uapi/linux/openat2.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/migrate_mode.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/delayed_call.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/ioprio.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/sched/rt.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/iocontext.h \
    $(wildcard include/config/BLK_ICQ) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/uapi/linux/ioprio.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/mount.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/mnt_idmapping.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/slab.h \
    $(wildcard include/config/FAILSLAB) \
    $(wildcard include/config/KFENCE) \
    $(wildcard include/config/SLUB_TINY) \
    $(wildcard include/config/SLUB_DEBUG) \
    $(wildcard include/config/SLAB_BUCKETS) \
    $(wildcard include/config/KVFREE_RCU_BATCHED) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/percpu-refcount.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/kasan.h \
    $(wildcard include/config/KASAN_STACK) \
    $(wildcard include/config/KASAN_VMALLOC) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/kasan-enabled.h \
    $(wildcard include/config/ARCH_DEFER_KASAN) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/kasan-tags.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/rw_hint.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/file_ref.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/uapi/linux/fs.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/uapi/linux/aio_abi.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/uapi/linux/unistd.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/arch/x86/include/asm/unistd.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/arch/x86/include/uapi/asm/unistd.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/arch/x86/include/generated/uapi/asm/unistd_64.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/arch/x86/include/generated/asm/unistd_64_x32.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/arch/x86/include/generated/asm/unistd_32_ia32.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/arch/x86/include/asm/compat.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/sched/task_stack.h \
    $(wildcard include/config/DEBUG_STACK_USAGE) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/uapi/linux/magic.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/arch/x86/include/asm/user32.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/asm-generic/compat.h \
    $(wildcard include/config/COMPAT_FOR_U64_ALIGNMENT) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/arch/x86/include/asm/syscall_wrapper.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/arch/x86/include/asm/user.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/arch/x86/include/asm/user_64.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/arch/x86/include/asm/fsgsbase.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/arch/x86/include/asm/vdso.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/uapi/linux/elf.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/uapi/linux/elf-em.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/kobject.h \
    $(wildcard include/config/UEVENT_HELPER) \
    $(wildcard include/config/DEBUG_KOBJECT_RELEASE) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/sysfs.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/kernfs.h \
    $(wildcard include/config/KERNFS) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/idr.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/kobject_ns.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/moduleparam.h \
    $(wildcard include/config/ALPHA) \
    $(wildcard include/config/PPC64) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/rbtree_latch.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/error-injection.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/asm-generic/error-injection.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/arch/x86/include/asm/module.h \
    $(wildcard include/config/UNWINDER_ORC) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/asm-generic/module.h \
    $(wildcard include/config/HAVE_MOD_ARCH_SPECIFIC) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/platform_device.h \
    $(wildcard include/config/HAS_IOMEM) \
    $(wildcard include/config/SUSPEND) \
    $(wildcard include/config/HIBERNATE_CALLBACKS) \
    $(wildcard include/config/PM_SLEEP) \
    $(wildcard include/config/SUPERH) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/device.h \
    $(wildcard include/config/GENERIC_MSI_IRQ) \
    $(wildcard include/config/ENERGY_MODEL) \
    $(wildcard include/config/PINCTRL) \
    $(wildcard include/config/ARCH_HAS_DMA_OPS) \
    $(wildcard include/config/DMA_DECLARE_COHERENT) \
    $(wildcard include/config/DMA_CMA) \
    $(wildcard include/config/SWIOTLB) \
    $(wildcard include/config/SWIOTLB_DYNAMIC) \
    $(wildcard include/config/ARCH_HAS_SYNC_DMA_FOR_DEVICE) \
    $(wildcard include/config/ARCH_HAS_SYNC_DMA_FOR_CPU) \
    $(wildcard include/config/ARCH_HAS_SYNC_DMA_FOR_CPU_ALL) \
    $(wildcard include/config/DMA_OPS_BYPASS) \
    $(wildcard include/config/DMA_NEED_SYNC) \
    $(wildcard include/config/IOMMU_DMA) \
    $(wildcard include/config/PM) \
    $(wildcard include/config/OF) \
    $(wildcard include/config/DEVTMPFS) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/dev_printk.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/energy_model.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/sched/cpufreq.h \
    $(wildcard include/config/CPU_FREQ) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/sched/topology.h \
    $(wildcard include/config/SCHED_CLUSTER) \
    $(wildcard include/config/SCHED_MC) \
    $(wildcard include/config/CPU_FREQ_GOV_SCHEDUTIL) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/sched/idle.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/sched/sd_flags.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/ioport.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/klist.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/pm.h \
    $(wildcard include/config/VT_CONSOLE_SLEEP) \
    $(wildcard include/config/CXL_SUSPEND) \
    $(wildcard include/config/PM_CLK) \
    $(wildcard include/config/PM_GENERIC_DOMAINS) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/device/bus.h \
    $(wildcard include/config/ACPI) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/device/class.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/device/devres.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/device/driver.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/arch/x86/include/asm/device.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/pm_wakeup.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/sound/core.h \
    $(wildcard include/config/SND_DYNAMIC_MINORS) \
    $(wildcard include/config/SND_MAX_CARDS) \
    $(wildcard include/config/SND_MAJOR) \
    $(wildcard include/config/SND_CTL_FAST_LOOKUP) \
    $(wildcard include/config/SND_DEBUG) \
    $(wildcard include/config/SND_CTL_DEBUG) \
    $(wildcard include/config/SND_MIXER_OSS) \
    $(wildcard include/config/SND_OSSEMUL) \
    $(wildcard include/config/ISA_DMA_API) \
    $(wildcard include/config/GAMEPORT) \
    $(wildcard include/config/SND_DEBUG_VERBOSE) \
    $(wildcard include/config/PCI) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/sound/soc.h \
    $(wildcard include/config/SND_SOC_COMPRESS) \
    $(wildcard include/config/SND_SOC_AC97_BUS) \
    $(wildcard include/config/SND_SOC_TOPOLOGY) \
    $(wildcard include/config/DMI) \
    $(wildcard include/config/DEBUG_FS) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/interrupt.h \
    $(wildcard include/config/IRQ_FORCED_THREADING) \
    $(wildcard include/config/GENERIC_IRQ_PROBE) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/irqreturn.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/hardirq.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/context_tracking_state.h \
    $(wildcard include/config/CONTEXT_TRACKING_USER) \
    $(wildcard include/config/CONTEXT_TRACKING) \
    $(wildcard include/config/RCU_DYNTICKS_TORTURE) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/ftrace_irq.h \
    $(wildcard include/config/HWLAT_TRACER) \
    $(wildcard include/config/OSNOISE_TRACER) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/vtime.h \
    $(wildcard include/config/VIRT_CPU_ACCOUNTING) \
    $(wildcard include/config/IRQ_TIME_ACCOUNTING) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/arch/x86/include/asm/hardirq.h \
    $(wildcard include/config/CPU_MITIGATIONS) \
    $(wildcard include/config/KVM_INTEL) \
    $(wildcard include/config/KVM) \
    $(wildcard include/config/GUEST_PERF_EVENTS) \
    $(wildcard include/config/X86_THERMAL_VECTOR) \
    $(wildcard include/config/X86_MCE_THRESHOLD) \
    $(wildcard include/config/X86_MCE_AMD) \
    $(wildcard include/config/X86_HV_CALLBACK_VECTOR) \
    $(wildcard include/config/HYPERV) \
    $(wildcard include/config/X86_POSTED_MSI) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/arch/x86/include/asm/irq.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/arch/x86/include/asm/irq_vectors.h \
    $(wildcard include/config/PCI_MSI) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/arch/x86/include/asm/sections.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/asm-generic/sections.h \
    $(wildcard include/config/HAVE_FUNCTION_DESCRIPTORS) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/of.h \
    $(wildcard include/config/OF_DYNAMIC) \
    $(wildcard include/config/SPARC) \
    $(wildcard include/config/OF_PROMTREE) \
    $(wildcard include/config/OF_KOBJ) \
    $(wildcard include/config/OF_NUMA) \
    $(wildcard include/config/OF_OVERLAY) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/mod_devicetable.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/uapi/linux/mei.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/uapi/linux/mei_uuid.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/property.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/fwnode.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/sound/ac97_codec.h \
    $(wildcard include/config/SND_AC97_POWER_SAVE) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/sound/ac97/regs.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/sound/pcm.h \
    $(wildcard include/config/SND_PCM_OSS) \
    $(wildcard include/config/SND_VERBOSE_PROCFS) \
    $(wildcard include/config/SND_PCM_XRUN_DEBUG) \
    $(wildcard include/config/X86) \
    $(wildcard include/config/PPC) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/sound/asound.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/uapi/sound/asound.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/sound/memalloc.h \
    $(wildcard include/config/GENERIC_ALLOCATOR) \
    $(wildcard include/config/SND_DMA_SGBUF) \
    $(wildcard include/config/HAS_DMA) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/dma-direction.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/sound/minors.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/poll.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/uapi/linux/poll.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/arch/x86/include/generated/uapi/asm/poll.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/uapi/asm-generic/poll.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/uapi/linux/eventpoll.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/mm.h \
    $(wildcard include/config/HAVE_ARCH_MMAP_RND_BITS) \
    $(wildcard include/config/HAVE_ARCH_MMAP_RND_COMPAT_BITS) \
    $(wildcard include/config/PPC32) \
    $(wildcard include/config/RISCV_USER_CFI) \
    $(wildcard include/config/ARM64_GCS) \
    $(wildcard include/config/ARCH_HAS_PKEYS) \
    $(wildcard include/config/ARCH_PKEY_BITS) \
    $(wildcard include/config/PARISC) \
    $(wildcard include/config/SPARC64) \
    $(wildcard include/config/ARM64_MTE) \
    $(wildcard include/config/HAVE_ARCH_USERFAULTFD_MINOR) \
    $(wildcard include/config/MSEAL_SYSTEM_MAPPINGS) \
    $(wildcard include/config/FIND_NORMAL_PAGE) \
    $(wildcard include/config/SHMEM) \
    $(wildcard include/config/ARCH_HAS_PTE_SPECIAL) \
    $(wildcard include/config/ASYNC_KERNEL_PGTABLE_FREE) \
    $(wildcard include/config/SPLIT_PTE_PTLOCKS) \
    $(wildcard include/config/HIGHPTE) \
    $(wildcard include/config/DEBUG_VM_RB) \
    $(wildcard include/config/PAGE_POISONING) \
    $(wildcard include/config/INIT_ON_ALLOC_DEFAULT_ON) \
    $(wildcard include/config/INIT_ON_FREE_DEFAULT_ON) \
    $(wildcard include/config/DEBUG_PAGEALLOC) \
    $(wildcard include/config/ARCH_WANT_OPTIMIZE_DAX_VMEMMAP) \
    $(wildcard include/config/HUGETLBFS) \
    $(wildcard include/config/MAPPING_DIRTY_HELPERS) \
    $(wildcard include/config/PAGE_POOL) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/pgalloc_tag.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/page_ext.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/stacktrace.h \
    $(wildcard include/config/ARCH_STACKWALK) \
    $(wildcard include/config/STACKTRACE) \
    $(wildcard include/config/HAVE_RELIABLE_STACKTRACE) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/page_ref.h \
    $(wildcard include/config/DEBUG_PAGE_REF) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/pgtable.h \
    $(wildcard include/config/ARCH_HAS_NONLEAF_PMD_YOUNG) \
    $(wildcard include/config/ARCH_HAS_HW_PTE_YOUNG) \
    $(wildcard include/config/GUP_GET_PXX_LOW_HIGH) \
    $(wildcard include/config/ARCH_WANT_PMD_MKWRITE) \
    $(wildcard include/config/HAVE_ARCH_HUGE_VMAP) \
    $(wildcard include/config/X86_ESPFIX64) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/memremap.h \
    $(wildcard include/config/DEVICE_PRIVATE) \
    $(wildcard include/config/PCI_P2PDMA) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/cacheinfo.h \
    $(wildcard include/config/ACPI_PPTT) \
    $(wildcard include/config/ARM) \
    $(wildcard include/config/ARCH_HAS_CPU_CACHE_ALIASING) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/cpuhplock.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/iommu-debug-pagealloc.h \
    $(wildcard include/config/IOMMU_DEBUG_PAGEALLOC) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/huge_mm.h \
    $(wildcard include/config/PGTABLE_HAS_HUGE_LEAVES) \
    $(wildcard include/config/PERSISTENT_HUGE_ZERO_FOLIO) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/vmstat.h \
    $(wildcard include/config/VM_EVENT_COUNTERS) \
    $(wildcard include/config/DEBUG_TLBFLUSH) \
    $(wildcard include/config/PER_VMA_LOCK_STATS) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/vm_event_item.h \
    $(wildcard include/config/BALLOON) \
    $(wildcard include/config/BALLOON_MIGRATION) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/pm_qos.h \
    $(wildcard include/config/CPU_IDLE) \
    $(wildcard include/config/PM_QOS_CPU_SYSTEM_WAKEUP) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/plist.h \
    $(wildcard include/config/DEBUG_PLIST) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/sound/control.h \
    $(wildcard include/config/SND_CTL_LED) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/sound/info.h \
    $(wildcard include/config/SND_PROC_FS) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/seq_file.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/string_helpers.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/ctype.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/string_choices.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/sound/compress_driver.h \
    $(wildcard include/config/SND_COMPRESS_ACCEL) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/uapi/sound/compress_offload.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/uapi/sound/compress_params.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/regmap.h \
    $(wildcard include/config/REGMAP) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/delay.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/arch/x86/include/asm/delay.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/asm-generic/delay.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/iopoll.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/io.h \
    $(wildcard include/config/HAS_IOPORT_MAP) \
    $(wildcard include/config/STRICT_DEVMEM) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/arch/x86/include/asm/io.h \
    $(wildcard include/config/MTRR) \
    $(wildcard include/config/X86_PAT) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/arch/x86/include/generated/asm/early_ioremap.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/asm-generic/early_ioremap.h \
    $(wildcard include/config/GENERIC_EARLY_IOREMAP) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/arch/x86/include/asm/shared/io.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/asm-generic/io.h \
    $(wildcard include/config/GENERIC_IOMAP) \
    $(wildcard include/config/TRACE_MMIO_ACCESS) \
    $(wildcard include/config/HAS_IOPORT) \
    $(wildcard include/config/GENERIC_IOREMAP) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/asm-generic/iomap.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/asm-generic/pci_iomap.h \
    $(wildcard include/config/NO_GENERIC_PCI_IOPORT_MAP) \
    $(wildcard include/config/GENERIC_PCI_IOMAP) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/logic_pio.h \
    $(wildcard include/config/INDIRECT_PIO) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/sound/soc-dapm.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/sound/soc-topology.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/uapi/sound/asoc.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/sound/soc-dpcm.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/sound/soc-dai.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/sound/soc-component.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/sound/soc-card.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/sound/soc-jack.h \
    $(wildcard include/config/GPIOLIB) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/sound/soc-acpi.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/acpi.h \
    $(wildcard include/config/ACPI_TABLE_LIB) \
    $(wildcard include/config/ACPI_DEBUGGER) \
    $(wildcard include/config/LOONGARCH) \
    $(wildcard include/config/RISCV) \
    $(wildcard include/config/ACPI_PROCESSOR_CSTATE) \
    $(wildcard include/config/ACPI_HOTPLUG_CPU) \
    $(wildcard include/config/ACPI_HOTPLUG_IOAPIC) \
    $(wildcard include/config/ACPI_WMI) \
    $(wildcard include/config/ACPI_THERMAL_LIB) \
    $(wildcard include/config/ACPI_HMAT) \
    $(wildcard include/config/ACPI_NUMA) \
    $(wildcard include/config/HIBERNATION) \
    $(wildcard include/config/ACPI_HOTPLUG_MEMORY) \
    $(wildcard include/config/ACPI_CONTAINER) \
    $(wildcard include/config/ACPI_GTDT) \
    $(wildcard include/config/ACPI_MRRM) \
    $(wildcard include/config/ACPI_EC) \
    $(wildcard include/config/ACPI_TABLE_UPGRADE) \
    $(wildcard include/config/ACPI_WATCHDOG) \
    $(wildcard include/config/ACPI_SPCR_TABLE) \
    $(wildcard include/config/ACPI_GENERIC_GSI) \
    $(wildcard include/config/ACPI_LPIT) \
    $(wildcard include/config/ACPI_PROCESSOR_IDLE) \
    $(wildcard include/config/ACPI_PCC) \
    $(wildcard include/config/ACPI_FFH) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/resource_ext.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/node.h \
    $(wildcard include/config/HMEM_REPORTING) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/acpi/acpi.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/acpi/platform/acenv.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/acpi/platform/acgcc.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/acpi/platform/aclinux.h \
    $(wildcard include/config/ACPI_REDUCED_HARDWARE_ONLY) \
    $(wildcard include/config/ACPI_DEBUG) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/arch/x86/include/asm/acenv.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/acpi/acnames.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/acpi/actypes.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/acpi/acexcep.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/acpi/actbl.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/acpi/actbl1.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/acpi/actbl2.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/acpi/actbl3.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/acpi/acrestyp.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/acpi/platform/acenvex.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/acpi/platform/aclinuxex.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/acpi/platform/acgccex.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/acpi/acoutput.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/acpi/acpiosxf.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/acpi/acpixf.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/acpi/acconfig.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/acpi/acbuffer.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/acpi/acpi_numa.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/fw_table.h \
    $(wildcard include/config/CXL_BUS) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/acpi/acpi_bus.h \
    $(wildcard include/config/X86_ANDROID_TABLETS) \
    $(wildcard include/config/ACPI_SYSTEM_POWER_STATES_SUPPORT) \
    $(wildcard include/config/ACPI_SLEEP) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/acpi/acpi_drivers.h \
    $(wildcard include/config/ACPI_DOCK) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/acpi/acpi_io.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/arch/x86/include/asm/acpi.h \
    $(wildcard include/config/ACPI_APEI) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/acpi/proc_cap_intel.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/arch/x86/include/asm/numa.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/arch/x86/include/asm/xen/hypervisor.h \
    $(wildcard include/config/XEN_PV_DOM0) \
    $(wildcard include/config/PVH) \
    $(wildcard include/config/XEN_DOM0) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/xen/xen.h \
    $(wildcard include/config/XEN_PVH) \
    $(wildcard include/config/XEN_BALLOON) \
    $(wildcard include/config/XEN_UNPOPULATED_ALLOC) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/xen/interface/hvm/start_info.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/xen/interface/xen.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/arch/x86/include/asm/xen/interface.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/arch/x86/include/asm/xen/interface_64.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/arch/x86/include/asm/pvclock-abi.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/arch/x86/include/asm/emulate_prefix.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/soundwire/sdw.h \
    $(wildcard include/config/SOUNDWIRE) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/bitfield.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/irq.h \
    $(wildcard include/config/GENERIC_IRQ_EFFECTIVE_AFF_MASK) \
    $(wildcard include/config/GENERIC_IRQ_IPI) \
    $(wildcard include/config/IRQ_DOMAIN_HIERARCHY) \
    $(wildcard include/config/DEPRECATED_IRQ_CPU_ONOFFLINE) \
    $(wildcard include/config/GENERIC_IRQ_MIGRATION) \
    $(wildcard include/config/GENERIC_PENDING_IRQ) \
    $(wildcard include/config/HARDIRQS_SW_RESEND) \
    $(wildcard include/config/GENERIC_IRQ_CHIP) \
    $(wildcard include/config/GENERIC_IRQ_MULTI_HANDLER) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/irqhandler.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/arch/x86/include/generated/asm/irq_regs.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/asm-generic/irq_regs.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/irqdesc.h \
    $(wildcard include/config/GENERIC_IRQ_STAT_SNAPSHOT) \
    $(wildcard include/config/GENERIC_IRQ_DEBUGFS) \
    $(wildcard include/config/SPARSE_IRQ) \
    $(wildcard include/config/IRQ_DOMAIN) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/irq_work.h \
    $(wildcard include/config/IRQ_WORK) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/arch/x86/include/asm/irq_work.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/arch/x86/include/asm/hw_irq.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/profile.h \
    $(wildcard include/config/PROFILING) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/irqdomain.h \
    $(wildcard include/config/IRQ_DOMAIN_NOMAP) \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/linux/irqdomain_defs.h \
  /usr/src/kernels/7.1.3-200.fc44.x86_64/include/sound/sdca.h \
    $(wildcard include/config/SND_SOC_SDCA) \

orion.o: $(deps_orion.o)

$(deps_orion.o):

orion.o: $(wildcard /usr/src/kernels/7.1.3-200.fc44.x86_64/tools/objtool/objtool)
